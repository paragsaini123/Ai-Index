// ai-index/components/Card.tsx
import React from 'react';
import { StyleSheet, View as RNView, Text } from 'react-native';
import { Link } from 'expo-router';
import { ProgressBar } from './progressBar';
import { useFonts } from 'expo-font';

type CardProps = {
  title: string;
  value: string;
  unit: string;
  progress: string;
  percentage: string;
  barColor: string;
  barContainerColor: string;
  cardStyle: string;
};

export const Card: React.FC<CardProps> = ({ title,cardStyle,barContainerColor, value,barColor, unit, progress, percentage }) => {
  const [loaded, error] = useFonts({
    'RobotoBold': require('../assets/fonts/RobotoBold.ttf'),
    'RobotoLight': require('../assets/fonts/RobotoLight.ttf'),
    'Roboto': require('../assets/fonts/RobotoRegular.ttf'),
    'RobotoThin': require('../assets/fonts/RobotoThin.ttf'),
  });
  return (
    <RNView style={styles.card}>
       <Link href={'segment/'+title.toLowerCase()} >
      <RNView style={styles.row}>
        
        <RNView style={styles.flex}>
          <Text style={styles.title}>{title}</Text>
        </RNView>
        <RNView style={styles.valueContainer}>
          <RNView>
            <Text style={styles.value}>{value}</Text>
          </RNView>
          <RNView style={styles.unitContainer}>
            <Text style={styles.unit}>{unit}</Text>
          </RNView>
        </RNView>
      </RNView>
      <RNView style={{width:'100%'}}>
      <ProgressBar progress={progress} containerColor={barContainerColor} barColor={barColor} />
      </RNView>
      <RNView style={{flexDirection:'row'}}>
        <Text style={styles.percentage}>{percentage}</Text>
        <Text style={{fontSize: 12,marginTop:8,marginLeft:.5,fontFamily:'RobotoBold'}}>%</Text>
      </RNView>
      </Link>
    </RNView>
  );
};

const styles = StyleSheet.create({
  card: {
    backgroundColor: '#f7f7f7',
    paddingHorizontal: 8,
    paddingVertical:4,
    opacity:1,
    paddingTop:8,
    marginVertical: 6,
    marginHorizontal:10,
    marginRight:14,
    borderRadius: 4,
    shadowOffset: { width: 2, height: 3 },
    shadowOpacity: 0.2,
    shadowColor: 'black',
  },
  row: {
    flexDirection: 'row',
    width:'100%'
  },
  flex: {
    flex: 1,
  },
  title: {
    fontFamily: 'RobotoBold',
    fontSize: 18,
    marginTop:2,
    marginLeft:2,
    fontWeight: 'bold',
  },
  valueContainer: {
    flexBasis: 100,
    justifyContent: 'flex-end',
    flexDirection: 'row',
    marginTop:4
  },
  value: {
    fontFamily: 'RobotoLight',
    fontSize: 18,
  },
  unitContainer: {
    justifyContent: 'flex-end',
    margin: 2,
    marginTop:-2
  },
  unit: {
    fontFamily: 'RobotoBold',
    fontSize: 10,
    fontWeight: 'bold',
  },
  progressBarContainer: {
    flexDirection: 'row',
    marginVertical: 10,
    backgroundColor: '#FF555F',
    borderRadius: 30,
    width:'100%'
  },
  progressBar: {
    width: '40%',
    height: 20,
    backgroundColor: '#BE252E',
    borderRadius: 30,
    justifyContent: 'center',
    alignItems: 'center',
  },
  progressText: {
    color: '#F6F6F6',
  },
  percentage: {
    
    fontSize: 20,
    fontFamily: 'RobotoBold',
    marginLeft:8
  },
});