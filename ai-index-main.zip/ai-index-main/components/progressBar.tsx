// ai-index/components/ProgressBar.tsx
import React from 'react';
import { View as RNView, Text, StyleSheet } from 'react-native';
import { useFonts } from 'expo-font';

type ProgressBarProps = {
  progress: string;
  barColor: string;
  containerColor: string;
};

export const ProgressBar: React.FC<ProgressBarProps> = ({ progress,barColor,containerColor }) => {
    const [loaded, error] = useFonts({
        'RobotoBold': require('../assets/fonts/RobotoBold.ttf'),
        'RobotoLight': require('../assets/fonts/RobotoLight.ttf'),
        'Roboto': require('../assets/fonts/RobotoRegular.ttf'),
        'RobotoThin': require('../assets/fonts/RobotoThin.ttf'),
      });
    return (
    <RNView style={[{backgroundColor:containerColor},styles.progressBarContainer]}>
      <RNView style={[{backgroundColor:barColor,width:''+(parseInt(progress)>100? 100 :progress)+'%'},styles.progressBar]}>
        <Text style={styles.progressText}>{progress}% goal</Text>
      </RNView>
    </RNView>
  );
};

const styles = StyleSheet.create({
  progressBarContainer: {
    flexDirection: 'row',
    marginVertical: 4,
   
    borderRadius: 30,
  },
  progressBar: {
   
    height: 20,
   
    borderRadius: 30,
    justifyContent: 'center',
    alignItems: 'center',
    paddingVertical:0
  },
  progressText: {
    color: '#F6F6F6',
    fontSize:10,
    fontFamily:'Roboto',
  },
});