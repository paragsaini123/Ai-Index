// ai-index/components/SectionLink.tsx
import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { Link } from 'expo-router';
import { useFonts } from 'expo-font';

type SectionLinkProps = {
  slug: string;
  currentSlug: string;
  href: string;
  title: string;
};

export const SectionLink: React.FC<SectionLinkProps> = ({ slug, currentSlug, href, title }) => {
  const isSelected = slug === currentSlug;
  const [loaded, error] = useFonts({
    'RobotoBold': require('../assets/fonts/RobotoBold.ttf'),
    'RobotoLight': require('../assets/fonts/RobotoLight.ttf'),
    'Roboto': require('../assets/fonts/RobotoRegular.ttf'),
    'RobotoThin': require('../assets/fonts/RobotoThin.ttf'),
  });

  return (
    <View style={isSelected ? styles.sectionSelected : styles.section}>
      <Link replace href={'segment/'+slug.toLowerCase()}>
        <View style={{flex:1}}>
          <Text style={isSelected ? styles.sectionSelectedText : styles.sectionText}>
            {title}
          </Text>
        </View>
      </Link>
    </View>
  );
};

const styles = StyleSheet.create({
    section:{
        margin:5,
        borderRadius:20,
        width:'30%',
        shadowColor: 'black',
        alignItems: 'center',
       paddingVertical:10,
        justifyContent: 'center',
        backgroundColor: 'white',
        shadowOffset: { width: 2, height: 2 },
        shadowOpacity: 0.2,
        
    },
    sectionSelectedText:{
        fontWeight:'bold',
        fontFamily:'RobotoBold',
        fontSize:20
    },
    sectionText:{
        fontWeight:'bold',
        fontFamily:'Roboto',
        fontSize:14
    },
    sectionSelected:{
        margin:5,
        padding:10,
        borderRadius:10,
        width:'30%',
        shadowColor: 'black',
        alignItems: 'center',
        backgroundColor: 'white',
        paddingVertical:10
    },
  });