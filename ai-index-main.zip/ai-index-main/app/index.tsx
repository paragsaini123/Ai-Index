import { Text, View, ImageBackground, Image, Dimensions, ScrollView, StyleSheet } from "react-native";
import { Card } from '../components/card';
import { Link } from 'expo-router';
import { useFonts } from 'expo-font';

const screenHeight = Dimensions.get('window').height;
const screenWidth = Dimensions.get('window').width;

export default function Index() {
  const [loaded, error] = useFonts({
    'RobotoBold': require('../assets/fonts/RobotoBold.ttf'),
    'RobotoLight': require('../assets/fonts/RobotoBold.ttf'),
    'RobotoRegular': require('../assets/fonts/RobotoBold.ttf'),
    'RobotoThin': require('../assets/fonts/RobotoThin.ttf'),
  });
  return (
    <ImageBackground
      source={require('../assets/images/background.jpeg')}
      style={styles.backgroundImage}
    >
      <View style={[styles.mainContainer]}>
        <ScrollView>
          <View style={styles.row}>
            <View style={styles.flexOne}>
              <View>
                <Text style={styles.boldText}>Hi Shalvi,</Text>
              </View>
              <View>
                <Text style={styles.lightText}>here's the</Text>
              </View>
              <View>
                <Text style={styles.boldText}>AI index</Text>
              </View>
              <View>
                <Text style={styles.boldText}>This Year</Text>
              </View>
            </View>
            <View style={styles.iconContainer}>
              <View style={styles.iconBackground}>
                <Image
                  style={styles.icon}
                  source={{ uri: 'https://s3-alpha-sig.figma.com/img/215c/fd14/ea9bf86858c957d506f9191c48e43c7f?Expires=1728864000&Key-Pair-Id=APKAQ4GOSFWCVNEHN3O4&Signature=OzK6yXCx3PEUbugC5BI5pLQzOmOpCVEPTss1Z7gfAq9S0zwKNB~krwd7jvVORXTNkhCssr7p52SJRiKZyH52JO4R26--RBYs7IYX3BSlVtg-H4LT4kxW0d4oRxBHMTB2OE-d~qLGHa~CvNyUlgG4GawEC5Z2fOkInqFGAr9oQBeIfh9fMyp4eplH2XOafdWxGhaWGjMzDgizdSgJbQhe5lcVCTxJ7usM5CTCwcrgRT4CqoF3tPf25i8Yn0hXg~X9jGfeY10IO1MLy97UeGJw5GM4M4M9aKmlBVWlaudyhusZa89LjB1lWaYSLdGrP-nWPEC0XHwH-CgHpGq63lt-1A__' }}
                />
              </View>
            </View>
            <View style={styles.container}>
      <Image
        style={styles.image}
        source={{ uri: 'https://s3-alpha-sig.figma.com/img/1c56/07bb/e53c859125bc091cdc7395a479022aca?Expires=1728864000&Key-Pair-Id=APKAQ4GOSFWCVNEHN3O4&Signature=mFhE9GrcWB5UFkVnFhtgVIZJbIf7m9uj7AWQLZs~6BdAlU2WXRFTNaBwLju~9R~qKy1C7SzunJBWUyKK6yC1wcfq9Gp0afKZjp6Tfs-~2j3ETCcUyuD00XudunP0q9El3foq6yIMT0EewJlpdLaBG90woWufKqRejMchaSpwMX37zCMr2PAtvMxl3kKSjJfl2RBxwVJYU~-UPBxXMio6jbGE-7w63zWRZyF12aeH1BBQwG6-jsd4JpxVf3ksYfuGiXxQMu9AksBbHs6ye8MaaRAnsI-drj7SFIYWn2lrLnojH6RaC8ieNAWkSRJLPxtBK-RBThKVs1u7t1dfN17r1A__' }}
      />
    </View>
          </View>
          <View style={{backgroundColor:'white'}}>
          <Card title="Contracts" value="494" unit="M" progress="92" barColor='#ff555f' barContainerColor='#f9dcdd' percentage="4.6" />
          <Card title="Revenue" cardStyle="{backgroundColor:'red'}"value="198" unit="M" progress="114" barContainerColor="" barColor="rgb(5 209 250)" percentage="5.7" />
          <Card title="Resource" value="3050" unit="M" progress="88" barContainerColor="rgb(191 212 237)" barColor="rgb(19 105 204)" percentage="2.2" />
          </View>
          {/* < View style={[styles.changeContainer,{width:'100%',height:275,}]}>
            <Text style={styles.boldText}>What's Changed</Text>
           <View style={{flex:1,backgroundColor:'#e3e3e3',alignItems:'center',justifyContent:'center'}}>
            <Text style={[styles.changeText,{width:'100%'}]}>
              Coming Soon
            </Text>
            </View>
          </View> */}
        </ScrollView>
      </View>
      <View style={[styles.footer, { width: screenWidth - 40 }]}>
        <View style={styles.footerRow}>
        <View style={{flexDirection:'row'}}>
            <Image style={{width:25,height:25}} source={{uri:'https://s3-alpha-sig.figma.com/img/7c4c/2723/8ea488bcaa40b3e1daccbf630481ccfd?Expires=1728864000&Key-Pair-Id=APKAQ4GOSFWCVNEHN3O4&Signature=SX6vAQ5clPC04TDb9EP3wzOi938Z-AndDOhF9c3Gona6X530HaQ1T~TaArZOJyRq5Ko-NKa3OEJWVcbBRF7RrVCrPidUis~-s61WbgHSxZEnInNsF-6U6ABhp-Qt532LsA9o2x58dT3DgLfQE94HfWsKlNYSjrxx1YjsnW6f0oOa9yRnu-mqVN8-qEygsEhdSTWiX-tHLFSs9ACC6E4Z59e6WQBEMSK4JpOpUBwyw47~vFLpXSoMD~r1grbEbRg24Xiq4GfmlwE23MNyI1OJ1XFa5w83YCVNZ20xYP9cI8ybqoHncv62Dv~U8sGIIOMwiE~BApM2boGl0E3dGb3VRA__'}}>

            </Image>
            <View style={{marginLeft:10,justifyContent:'center',flex:1}}>
            <Text style={{fontSize:14,fontFamily:'Roboto'}}>Ask me anything about these accounts</Text>
            </View>
          </View>
        </View>
      </View>
    </ImageBackground>
  );
}

const styles = StyleSheet.create({
  backgroundImage: {
    flex: 1,
    height:screenHeight,
    width:screenWidth,
    justifyContent:'center',
  },
  mainContainer: {
    zIndex: 1,
    marginTop:20,
    height: (screenHeight),width:screenWidth
  },
  row: {
    flexDirection: 'row',
    margin: 20,
  },
  flexOne: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'flex-start',
  },
  boldText: {
    fontSize: 30,
    fontFamily: 'RobotoBold',
    fontWeight: 'bold',
    width:'100%',
    backgroundColor:'white'
  },
  lightText: {
    fontSize: 30,
    backgroundColor:'white',
    fontFamily: 'RobotoThin',
    fontWeight: '300',
  },
  container: {
    width: 40,
    borderRadius: 60,
    alignItems: 'center',
  },
  image: {
    width: 40,
    height: 35,
    borderRadius: 60,
  },
  iconContainer: {
    width: 50,
    alignItems: 'center',
    marginRight: '2%',
    marginTop: 8,
  },
  iconBackground: {
    backgroundColor: '#F5F3F3',
    borderRadius: 60,
    alignItems: 'center',
 
  },
  icon: {
    width: 25,
    height: 20,
    
  },
  changeContainer: {
    marginVertical: 20,
    marginHorizontal: 25,
  },
  changeText: {
    flex: 1,
    marginTop: 20,
    justifyContent: 'center',
  },
  footer: {
    shadowColor: 'black',
    zIndex: 999,
    backgroundColor: 'white',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.2,
    bottom: 0,
    position: 'absolute',
    margin: 20,
    paddingHorizontal: 30,
    paddingTop: 20,
    paddingBottom: 15,
    borderRadius: 40,
  },
  footerRow: {
    flexDirection: 'row',
  },
});