import { Text } from 'react-native';

export default function Segment() {
  return <Text>Top-level page</Text>;
}