import {
  Text,
  View,
  ImageBackground,
  Image,
  Dimensions,
  ScrollView,
  StyleSheet,
  Button,
} from "react-native";
import { Card } from "../../components/card";
import { useLocalSearchParams } from "expo-router";
import { Link } from "expo-router";
import { SectionLink } from "@/components/SectionLink";
import { ProgressBar } from "@/components/progressBar";
import { useFonts } from "expo-font";
import { useEffect, useState } from "react";
import  { Pressable } from 'react-native';

const screenHeight = Dimensions.get("window").height;
const screenWidth = Dimensions.get("window").width;

const segmentData = {
  label: "Contracts",
  aiOnly: {
    name: "",
    value: "30.6375",
    suffix: "M",
    target: "1.3",
  },
  aiTotal: {
    name: "",
    value: "122.55",
    suffix: "M",
    target: "2.4",
  },
  metrices: [
    {
      name: "Booking",
      value: "86861.0",
      suffix: "M",
      target: "22.19983652041768",
    },
    {
      name: "Renewal",
      value: "86861.0",
      suffix: "M",
      target: "22.19983652041768",
    },
    {
      name: "Existing",
      value: "-38535.3625",
      suffix: "M",
      target: "-125778.41697266424",
    },
  ],
};

const segmentData1 = {
  label: "Contracts",
  aiOnly: {
    name: "",
    value: "494",
    suffix: "M",
    target: "2.5",
    percentage:"40"
  },
  aiTotal: {
    name: "",
    value: "10740",
    suffix: "M",
    target: "2.9",
  },
  metrices: [
    {
      name: "Booking",
      value: "230",
      suffix: "M",
      target: "6.4",
      percentage:"128"
    },
    {
      name: "Renewal",
      value: "17.0",
      suffix: "M",
      target: "1",
       percentage:"20"
    },
    {
      name: "Existing",
      value: "247",
      suffix: "M",
      target: 0,

    },
  ],
};

const segmentData2 = {
  label: "Contracts",
  aiOnly: {
    name: "",
    value: "198",
    suffix: "M",
    target: "1.8",
  },
  aiTotal: {
    name: "",
    value: "3507",
    suffix: "M",
    target: "3.1",
  },
  metrices: null,
};

const segmentData3 = {
  label: "Contracts",
  aiOnly: {
    name: "",
    value: "3050",
    suffix: "M",
    target: "7.5",
  },
  aiTotal: {
    name: "",
    value: "139000",
    suffix: "M",
    target: "5.9",
  },
  metrices: null,
};

const filterData1 = {
  label: "Contracts",
  aiOnly: {
    name: "",
    value: "700",
    suffix: "M",
    target: "2.5",
    percentage:"40"
  },
  aiTotal: {
    name: "",
    value: "12000",
    suffix: "M",
    target: "2.9",
  },
  metrices: [
    {
      name: "Booking",
      value: "400",
      suffix: "M",
      target: "6.4",
      percentage:"128"
    },
    {
      name: "Renewal",
      value: "500",
      suffix: "M",
      target: "1",
       percentage:"20"
    },
    {
      name: "Existing",
      value: "700",
      suffix: "M",
      target: 0,

    },
  ],
};

const filterData2 = {
  label: "Contracts",
  aiOnly: {
    name: "",
    value: "600",
    suffix: "M",
    target: "2.5",
    percentage:"40"
  },
  aiTotal: {
    name: "",
    value: "13000",
    suffix: "M",
    target: "2.9",
  },
  metrices: [
    {
      name: "Booking",
      value: "650",
      suffix: "M",
      target: "6.4",
      percentage:"128"
    },
    {
      name: "Renewal",
      value: "400",
      suffix: "M",
      target: "1",
       percentage:"20"
    },
    {
      name: "Existing",
      value: "550",
      suffix: "M",
      target: 0,

    },
  ],
};

const filterData3 = {
  label: "Contracts",
  aiOnly: {
    name: "",
    value: "750",
    suffix: "M",
    target: "2.5",
    percentage:"40"
  },
  aiTotal: {
    name: "",
    value: "11000",
    suffix: "M",
    target: "2.9",
  },
  metrices: [
    {
      name: "Booking",
      value: "400",
      suffix: "M",
      target: "6.4",
      percentage:"128"
    },
    {
      name: "Renewal",
      value: "700",
      suffix: "M",
      target: "1",
       percentage:"20"
    },
    {
      name: "Existing",
      value: "350",
      suffix: "M",
      target: 0,

    },
  ],
};

const toggleFilter = () => {

}

export default function Segment() {

  const [loaded, error] = useFonts({
    RobotoBold: require("../../assets/fonts/RobotoBold.ttf"),
    RobotoLight: require("../../assets/fonts/RobotoLight.ttf"),
    Roboto: require("../../assets/fonts/RobotoRegular.ttf"),
    RobotoThin: require("../../assets/fonts/RobotoThin.ttf"),
  });
  const { slug } = useLocalSearchParams();

  const toggleFilter = () => {
    console.log('working')
    setshowFilters(!showFilters);
  }

  const [segment, setSegment] = useState(segmentData);
  const [showFilters, setshowFilters] = useState(false);

  const updateData = (data) => {
    setshowFilters(false)
    setSegment(data);
  };
  // -------------------------------get data api call on page laod---------------------------

  useEffect(() => {
    async function getFetchData() {
      try {
        const res = await fetch(
          `http://20.235.240.161/apiindex/segment?label=${slug}`
        );
        const resData = await res.json();
        console.log(resData);
        if (resData) {
          setSegment(resData);
        } else {
          setSegment(segmentData);
        }

        if(slug === 'contracts'){
          setSegment(segmentData1)
        }
        else if(slug === 'revenue'){
          setSegment(segmentData2)
        }
        else if(slug === 'resource'){
          setSegment(segmentData3)
        }




      } catch (error) {
        console.log(error);
      }
    }
    getFetchData();
  }, [slug]);

  return (
    <ImageBackground
    source={require('../../assets/images/background.jpeg')}
    style={styles.backgroundImage}
  >
     <Pressable onPress={() => setshowFilters(false)}>  
    <View style={[styles.mainContainer,{position:'relative'}]}>
      
     {showFilters && <View style={{shadowOffset: { width: 2, height: 3 },
  shadowOpacity: 0.2,backgroundColor:'#f7f7f7',borderRadius:4,position:'absolute',left:80,top:26,width:250,height:450,zIndex:998}}>
        <ScrollView>
        <View style={{padding:20}}>
          <Text style={styles.filterItem}>Segment / Unit</Text>
          <Text onPress={() => updateData(filterData1)} style={styles.filterFirstItem}>Consumer & Healthcare</Text>
          <Text onPress={() => updateData(filterData2)} style={styles.filterFirstItem}>Hi Tech & Manufacturing</Text>
          <Text onPress={() => updateData(filterData3)} style={styles.filterFirstItem}>Financial Services</Text>
         
          <Text style={styles.filterItem}>Capability</Text>
          <Text onPress={() => updateData(filterData1)} style={styles.filterFirstItem}>Analytics</Text>
          <Text onPress={() => updateData(filterData2)} style={styles.filterFirstItem}>Consulting</Text>
          <Text onPress={() => updateData(filterData3)} style={styles.filterFirstItem}>Experience</Text>
          <Text style={styles.filterFirstItem}>Managed Services - BPM</Text>
          <Text style={styles.filterFirstItem}>Managed Services - IT</Text>
          <Text style={styles.filterFirstItem}>Tech Services</Text>
          <Text style={styles.filterItem}>Archetype</Text>
          <Text style={styles.filterFirstItem}>Champion</Text>
          <Text style={styles.filterFirstItem}>Growth</Text>
          <Text style={styles.filterFirstItem}>Non Named</Text>
          <Text style={styles.filterFirstItem}>Value Maintain</Text>
          <Text style={styles.filterFirstItem}>Value Potential</Text>
         
          <Text style={styles.filterItem}>Delivery Location</Text>
          <Text style={styles.filterFirstItem}>Americas</Text>
          <Text style={styles.filterFirstItem}>APAC</Text>
          <Text style={styles.filterFirstItem}>Europe</Text>
          <Text style={styles.filterFirstItem}>India</Text>
          <Text style={styles.filterFirstItem}>Middle East</Text>
          <Text style={styles.filterFirstItem}>South Africa</Text>

          <Text style={styles.filterItem}>Region</Text>
          <Text style={styles.filterFirstItem}>Africa</Text>
          <Text style={styles.filterFirstItem}>Asia</Text>
          <Text style={styles.filterFirstItem}>Europe</Text>
          <Text style={styles.filterFirstItem}>North America</Text>
          <Text style={styles.filterFirstItem}>Oceania</Text>
          <Text style={styles.filterFirstItem}>South America</Text>

          <Text style={styles.filterItem}>AI Offering</Text>
          <Text style={styles.filterFirstItem}>GenAI</Text>
          <Text style={styles.filterFirstItem}>AI & Conversational AI</Text>
          <Text style={styles.filterFirstItem}>Data Engineering</Text>
          
         
          
        </View>
        </ScrollView>
      </View>
}
      <ScrollView>
        <View style={styles.row}>
          <View style={[styles.flexOne]}>
          <Pressable
                onPress={toggleFilter}
                >
            <View  style={{zIndex:999,backgroundColor:'#f7f7f7',width:50,alignItems:'center',marginTop:10,marginLeft:10}}>
          <Image style={{zIndex:999,width:25,height:25,marginLeft:10}} source={{uri:'https://s3-alpha-sig.figma.com/img/0616/aed2/2316a0c3c2f8e9d70d181edc450b572d?Expires=1729468800&Key-Pair-Id=APKAQ4GOSFWCVNEHN3O4&Signature=eDZNs5uY1m63j0arZOIbVrjSNTxB6k82WE-Uq22c3u-taNRpLvE01dW~QPl9lstLpAsuFBJGuWB98WUqfaV4G4sT2Jrbmq4xLax2qh4lxbi-e6MQiTVfFzUtjeqnM64U678dtEoxjdR4SJEM06wAFbxAT6TFvS8Efg2xpSP6oBg0Ee-rmqIfvR8KTnsw-84C~QbGu~a5khh-fBLoLJMC9dZCp8kegH11saP1rfDe-xGxYysAlQ7LGB6v3a4TpsJd4wEtlxKF0nsZ8wX3d5pPonloKxvYc7ObwY~qiQaRJss3837u~2T~xvok7uWE8pL18vVT7NDdibvRd0J0Iza9Wg__'}} />
          </View>
          </Pressable>
          </View>
          <View style={styles.iconContainer}>
              <View style={styles.iconBackground}>
                <Image
                  style={styles.icon}
                  source={{
                    uri: "https://s3-alpha-sig.figma.com/img/215c/fd14/ea9bf86858c957d506f9191c48e43c7f?Expires=1728864000&Key-Pair-Id=APKAQ4GOSFWCVNEHN3O4&Signature=OzK6yXCx3PEUbugC5BI5pLQzOmOpCVEPTss1Z7gfAq9S0zwKNB~krwd7jvVORXTNkhCssr7p52SJRiKZyH52JO4R26--RBYs7IYX3BSlVtg-H4LT4kxW0d4oRxBHMTB2OE-d~qLGHa~CvNyUlgG4GawEC5Z2fOkInqFGAr9oQBeIfh9fMyp4eplH2XOafdWxGhaWGjMzDgizdSgJbQhe5lcVCTxJ7usM5CTCwcrgRT4CqoF3tPf25i8Yn0hXg~X9jGfeY10IO1MLy97UeGJw5GM4M4M9aKmlBVWlaudyhusZa89LjB1lWaYSLdGrP-nWPEC0XHwH-CgHpGq63lt-1A__",
                  }}
                />
              </View>
            </View>
            <View style={styles.container}>
              <Image
                style={styles.image}
                source={{
                  uri: "https://s3-alpha-sig.figma.com/img/1c56/07bb/e53c859125bc091cdc7395a479022aca?Expires=1728864000&Key-Pair-Id=APKAQ4GOSFWCVNEHN3O4&Signature=mFhE9GrcWB5UFkVnFhtgVIZJbIf7m9uj7AWQLZs~6BdAlU2WXRFTNaBwLju~9R~qKy1C7SzunJBWUyKK6yC1wcfq9Gp0afKZjp6Tfs-~2j3ETCcUyuD00XudunP0q9El3foq6yIMT0EewJlpdLaBG90woWufKqRejMchaSpwMX37zCMr2PAtvMxl3kKSjJfl2RBxwVJYU~-UPBxXMio6jbGE-7w63zWRZyF12aeH1BBQwG6-jsd4JpxVf3ksYfuGiXxQMu9AksBbHs6ye8MaaRAnsI-drj7SFIYWn2lrLnojH6RaC8ieNAWkSRJLPxtBK-RBThKVs1u7t1dfN17r1A__",
                }}
              />
            </View>
          </View>
          <View
            style={{
              justifyContent: "center",
              flexDirection: "row",
              marginVertical: 10,
              marginHorizontal: 5,
            }}
          >
            <SectionLink
              slug="contracts"
              currentSlug={slug}
              href="segment/contracts"
              title="Contracts"
            />

            <SectionLink
              slug="revenue"
              currentSlug={slug}
              href="segment/contracts"
              title="Revenue"
            />
            <SectionLink
              slug="resource"
              currentSlug={slug}
              href="segment/contracts"
              title="Resource"
            />
          </View>
          <View style={{}}>
            <Image
              source={require("../../assets/images/image.png")}
              style={{ marginLeft: 30, zIndex: 999, width: "90%" }}
            />
          </View>
          <View
            style={{
              margin: 20,
              shadowColor: "black",
              borderRadius: 5,
              shadowOffset: { width: 4, height: 4 },
              shadowOpacity: 0.2,
              paddingVertical: 10,
              paddingHorizontal: 15,
              backgroundColor: "#f7f7f7",
            }}
          >
            <View style={{ marginBottom: 10, flexDirection: "row" }}>
              <View style={{ width: "45%" }}>
                <View
                  style={[
                    {
                      flexDirection: "row",
                      justifyContent: "flex-start",
                      backgroundColor: "yelslow",
                    },
                  ]}
                >
                  <Text
                    style={{
                      marginTop: 14,
                      marginRight: 12,
                      fontSize: 16,
                      fontFamily: "Robotobold",
                    }}
                  >
                    AI Only
                  </Text>
                  <Text style={{ fontSize: 28, fontFamily: "RobotoLight" }}>
                    {segment.aiOnly.value}
                  </Text>
                  <Text
                    style={{
                      marginTop: 12,
                      marginLeft:4,
                      fontSize: 16,
                      fontFamily: "Roboto",
                    }}
                  >
                    {segment.aiOnly.suffix}
                  </Text>
                </View>

                <View style={{ alignItems: "flex-end" }}>
                  <Text
                    style={{
                      fontSize: 16,
                      color: "green",
                      fontFamily: "Roboto",
                      marginRight: 20,
                    }}
                  >
                   {segment.aiOnly.target}%
                  </Text>
                </View>
              </View>
              <View style={{ marginLeft: "10%", width: "45%" }}>
                <View
                  style={[
                    {
                      flexDirection: "row",
                      justifyContent: "flex-end",
                      backgroundColor: "yelslow",
                    },
                  ]}
                >
                  <Text
                    style={{
                      marginTop: 14,
                      marginRight: 12,
                      fontSize: 16,
                      fontFamily: "Robotobold",
                    }}
                  >
                    Total
                  </Text>
                  <Text style={{ fontSize: 28, fontFamily: "RobotoLight" }}>
                    {segment.aiTotal.value}
                  </Text>
                  <Text
                    style={{
                      marginTop: 12,
                      marginLeft:4,
                      fontSize: 16,
                      fontFamily: "Roboto",
                    }}
                  >
                    {segment.aiTotal.suffix}
                  </Text>
                </View>
                <View style={{ alignItems: "flex-end" }}>
                  <Text
                    style={{
                      fontSize: 14,
                      fontFamily: "Roboto",
                      marginRight: -4,
                    }}
                  >
                     {segment.aiTotal.target}%
                  </Text>
                </View>
              </View>
              <View style={{ width: "50%" }}></View>
            </View>

            <ProgressBar
              progress={segment.aiOnly.percentage}
              barColor="#ff555f"
              containerColor="#f9dcdd"
            />
          </View>
          <View
            style={{
              flexDirection: "row",
              marginHorizontal: 20,
              borderRadius: 5,
              justifyContent: "space-between",
            }}
          >
            {segment?.metrices &&
              segment.metrices.length > 0 &&
              segment.metrices.map((item, i) => (
                <View
                  key={item.name}
                  style={{
                    width: "31%",
                    alignItems: "center",
                    borderRadius: 5,
                    shadowColor:
                      i === 0 ? "black" : i === 1 ? "white" : "black",
                    shadowOffset: { width: 4, height: 4 },
                    shadowOpacity: 0.2,
                    paddingVertical: 10,
                    paddingHorizontal: 15,
                    backgroundColor:
                      i === 0 ? "#f7f7f7" : i === 1 ? "white" : "#595c60",
                  }}
                >
                  <Text
                    style={{
                      fontSize: 14,
                      fontFamily: i === 2 ? "Roboto" : "Robotobold",
                      color: i === 2 ? "white" : "black",
                    }}
                  >
                    {item.name}
                  </Text>
                  <Text
                    style={{
                      fontSize: 16,
                      fontFamily: i === 2 ? "RobotoThin" : "Roboto",
                      color: i === 2 ? "white" : "black",
                    }}
                  >
                    {item.value}
                    {item.suffix}
                  </Text>
                  <Text
                    style={{
                      fontSize: 16,
                      fontFamily: i === 2 ? "Roboto" : "Robotobold",
                      color: i === 2 ? "white" : "black",
                    }}
                  >
                    {item.target === 0 ? '' : item.target+'%'}
                  </Text>
                  <View style={{ width: "100%", marginTop: 4 }}>
                  
                  {item.target !=0 ? <ProgressBar
                      progress={item.percentage}
                      barColor="#ff555f"
                      containerColor="#f9dcdd"
                    /> : ''}
                  </View>

                  {/* <Text style={{width:'100%',marginLeft:5}}>60%goal</Text> */}
                </View>
              ))}
          </View>
        </ScrollView>
      </View>
      <View style={[styles.footer, { width: screenWidth - 40 }]}>
        <View style={styles.footerRow}>
          <View style={{ flexDirection: "row" }}>
            <Image
              style={{ width: 25, height: 25 }}
              source={{
                uri: "https://s3-alpha-sig.figma.com/img/7c4c/2723/8ea488bcaa40b3e1daccbf630481ccfd?Expires=1728864000&Key-Pair-Id=APKAQ4GOSFWCVNEHN3O4&Signature=SX6vAQ5clPC04TDb9EP3wzOi938Z-AndDOhF9c3Gona6X530HaQ1T~TaArZOJyRq5Ko-NKa3OEJWVcbBRF7RrVCrPidUis~-s61WbgHSxZEnInNsF-6U6ABhp-Qt532LsA9o2x58dT3DgLfQE94HfWsKlNYSjrxx1YjsnW6f0oOa9yRnu-mqVN8-qEygsEhdSTWiX-tHLFSs9ACC6E4Z59e6WQBEMSK4JpOpUBwyw47~vFLpXSoMD~r1grbEbRg24Xiq4GfmlwE23MNyI1OJ1XFa5w83YCVNZ20xYP9cI8ybqoHncv62Dv~U8sGIIOMwiE~BApM2boGl0E3dGb3VRA__",
              }}
            ></Image>
            <View style={{ marginLeft: 10, justifyContent: "center", flex: 1 }}>
              <Text style={{ fontSize: 14, fontFamily: "Roboto" }}>
                Ask me anything about these accounts
              </Text>
            </View>
          </View>
        </View>
      </View>
      </Pressable>
        </ImageBackground>
      );
    }
    
    const styles = StyleSheet.create({
      filterItem:{
        fontSize: 14,
        fontFamily: 'Roboto',
        marginBottom:14,
        fontWeight:'bold'
      },
      filterFirstItem:{
        fontSize: 14,
        fontFamily: 'Roboto',
        marginLeft:18,
        marginBottom:14
      },
      backgroundImage: {
        flex: 1,
        height:screenHeight,
        width:screenWidth,
        justifyContent:'center'
      },
      mainContainer: {
        zIndex: 1,
        marginTop:20,
        height: (screenHeight),width:screenWidth
      },
      row: {
        flexDirection: 'row',
        margin: 20,
      },
    
      flexOne: {
        flex: 1,
      },
      boldText: {
        fontSize: 30,
        fontFamily: 'Roboto',
        fontWeight: 'bold',
      },
      lightText: {
        fontSize: 30,
        fontFamily: 'Roboto',
        fontWeight: '300',
      },
      container: {
        width: 45,
        borderRadius: 60,
        alignItems: 'center',
      },
      image: {
        width: 45,
        height: 40,
        borderRadius: 60,
      },
      iconContainer: {
        width: 50,
        alignItems: 'center',
        marginRight: '2%',
        marginTop: 8,
      },
      iconBackground: {
        backgroundColor: '#F5F3F3',
        borderRadius: 60,
        alignItems: 'center',
     
      },
      icon: {
        width: 25,
        height: 20,
        
      },
      changeContainer: {
        marginVertical: 20,
        marginHorizontal: 25,
      },
      changeText: {
        flex: 1,
        marginTop: 20,
        justifyContent: 'center',
      },
      footer: {
        shadowColor: 'black',
        zIndex: 999,
        backgroundColor: 'white',
        shadowOffset: { width: 0, height: 4 },
        shadowOpacity: 0.2,
        bottom: 0,
        position: 'absolute',
        margin: 20,
        paddingHorizontal: 30,
        paddingTop: 20,
        paddingBottom: 15,
        borderRadius: 40,
      },
      footerRow: {
        flexDirection: 'row',
      },
    });
